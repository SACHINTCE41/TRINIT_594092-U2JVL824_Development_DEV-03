const locationmyplace =() =>{

     const status = document.querySelector('.status');

     const success = (position)=> {

       console.log(position)
     }
     const error=() =>{

     status.textContent = 'unable to retrive your location';
     }

     navigator.geolocation.getCurrentPosition(success, error);

}

document.querySelector('.find-state').addEventListener('click',locationmyplace);
